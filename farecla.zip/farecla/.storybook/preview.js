import '../color/colors.css';
import '../css/styles.src.css';
import fareclaSvgSprite from '../images/sprite.svg';
import breakpoints from '../farecla.breakpoints.yml';
import Twig from 'twig';
import { addDrupalExtensions } from 'drupal-twig-extensions/twig';
import DrupalAttributes from 'drupal-attribute';
import once from '@drupal/once';
window.once = once;
addDrupalExtensions(Twig, {
  // Optionally, set options to configure how the Drupal
});
const allTwigPatternTemplates = import.meta.glob(
  '../templates/patterns/**/*.html.twig',
  { as: 'raw', import: 'default', eager: true },
);

import.meta.glob(['../templates/patterns/**/*.src.css'], {
  import: 'default',
  eager: true,
});
const componentsJS = import.meta.glob(['../templates/patterns/**/*.src.js']);
for (const path in componentsJS) {
  componentsJS[path]();
}

// here we initiate all twig templates to save them in cache of Twig.Templates.registry
// and get by reference in
// render of farecla.js
for (const [path, data] of Object.entries(allTwigPatternTemplates)) {
  Twig.twig({
    attributes: new DrupalAttributes(),
    id: path.replace('../templates/patterns/', '@'),
    data: data,
    allowInlineIncludes: true,
  });
}

const fareclaMediaBreakpoints = Object.keys(breakpoints).reduce(
  (a, i) =>
    Object.assign(a, {
      [i.split('.').pop()]: breakpoints[i].mediaQuery,
    }),
  {},
);

export const parameters = {
  actions: { argTypesRegex: '^on[A-Z].*' },
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
  // Maybe load only Twig.Template.Registry somehow here.
  Twig: { ...Twig },
  backgrounds: {
    values: [{ name: 'grey', value: '#eee' }],
  },
};

// Drupal + drupalSettings

window.Drupal = {
  behaviors: {},
};
window.drupalSettings = {
  fareclaSvgSprite,
  fareclaMediaBreakpoints,
};

((Drupal, drupalSettings) => {
  document.addEventListener('DOMContentLoaded', () => {
    Drupal.t = function (str) {
      return str;
    };

    Drupal.throwError = function (error) {
      setTimeout(function () {
        throw error;
      }, 0);
    };

    Drupal.attachBehaviors = function (context, settings) {
      context = context || document;
      settings = settings || drupalSettings;
      const behaviors = Drupal.behaviors;
      // Execute all of them.
      Object.keys(behaviors || {}).forEach((i) => {
        if (typeof behaviors[i].attach === 'function') {
          // Don't stop the execution of behaviors in case of an error.
          try {
            behaviors[i].attach(context, settings);
          } catch (e) {
            Drupal.throwError(e);
          }
        }
      });
    };

    Drupal.attachBehaviors(document, drupalSettings);
  });
})(Drupal, window.drupalSettings);
