// (({ behaviors }) => {
//   behaviors.fareclaAtomTextField = {
//     attach: (context) => {
//       once('a-input-text', '.a-input-text', context).forEach((el) => {
//         behaviors.fareclaAtomTextField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
