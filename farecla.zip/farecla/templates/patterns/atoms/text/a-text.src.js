// (({ behaviors }) => {
//   behaviors.fareclaAtomText = {
//     attach: (context) => {
//       once('a-text', '.a-text', context).forEach((el) => {
//         behaviors.fareclaAtomText.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
