import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { useEffect } from '@storybook/client-api';
import DrupalAttribute from 'drupal-attribute';
import description from './a-text.component.yml';

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.content =
    args.content ||
    'Lorem ipsum Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz 1 2 3 4 5 6 7 8 9 10 ! @ # $ % ^ & * ( ) _ + { } [ ] . , | " : ; ?';
  if (args.tag === 'a' || args.link) {
    data.attributes.setAttribute('href', args.href || '#');
  }
  // useEffect(() => {}, [args]);
  return template.render(data);
};
export default {
  title: 'Atoms / Text',
  // parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};
