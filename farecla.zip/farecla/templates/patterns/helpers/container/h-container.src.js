// (({ behaviors }) => {
//   behaviors.fareclaHelperContainer = {
//     attach: (context) => {
//       once('h-container', '.h-container', context).forEach((el) => {
//         behaviors.fareclaHelperContainer.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
