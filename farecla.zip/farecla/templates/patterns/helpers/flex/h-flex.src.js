// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaHelperFlex = {
//     attach: (context) => {
//       once('h-flex', '.h-flex', context).forEach((el) => {
//         behaviors.fareclaHelperFlex.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
