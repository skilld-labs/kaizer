import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { useEffect } from '@storybook/client-api';
import DrupalAttribute from 'drupal-attribute';
import description from './h-grid.component.yml';

const defContent = () => {
  const items = [];
  for (let i = 1; i <= 10; i++) {
    items.push(
      `<div style="text-align: center; padding: 30px 16px; background-color: var(--color-grey-light-grey); color: var(--color-grey-black);">Grid item ${i}</div>`,
    );
  }
  return items;
};

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.items = args.items || defContent();
  // useEffect(() => { place-your-js-code-here }, [args]);
  return template.render(data);
};

export default {
  title: 'Helpers / Grid',
  // parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};
