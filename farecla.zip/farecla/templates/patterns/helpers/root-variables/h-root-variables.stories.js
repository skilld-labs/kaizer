export default {
  title: 'Helpers / Root variables',
};
