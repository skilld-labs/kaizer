// (({ behaviors }) => {
//   behaviors.fareclaMoleculeBanner = {
//     attach: (context) => {
//       once('m-banner', '.m-banner', context).forEach((el) => {
//         behaviors.fareclaMoleculeBanner.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
