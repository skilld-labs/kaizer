import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { useEffect } from '@storybook/client-api';
import DrupalAttribute from 'drupal-attribute';
import { ResponsiveImage } from '@farecla-components/atoms/image/a-image.stories';
import { Basic as TextField } from '@farecla-components/molecules/text-field/m-text-field.stories';
import { Basic as Button } from '@farecla-components/atoms/button/a-button.stories';
import { faker } from '@faker-js/faker';
import description from './m-banner.ui_patterns.yml';

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.media = ResponsiveImage.render({
    group: 'banner',
  });
  if (!args.noTitle) {
    data.title = TextField.render({
      item: args.title || 'Lorem ipsum',
      item_type: 'a-text--header-2',
    });
  }
  if (!args.noBody) {
    data.body = TextField.render({
      item: args.body || faker.lorem.sentences(),
    });
  }
  if (!args.noCTA) {
    data.cta = Button.render({
      content: args.cta || 'Lorem ipsum',
      type: 'a-button--three',
      trailing_icon: 'chevron',
      link: true,
    });
  }
  // useEffect(() => { place-your-js-code-here }, [args]);
  return template.render(data);
};

export default {
  title: 'Molecules / Banner',
  // parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};

export const NoBody = {
  render: (args = {}) => {
    args.noBody = true;
    return BasicRender(args);
  },
};

export const NoCTA = {
  render: (args = {}) => {
    args.noCTA = true;
    return BasicRender(args);
  },
};

export const onlyCTA = {
  render: (args = {}) => {
    args.noTitle = true;
    args.noBody = true;
    return BasicRender(args);
  },
};
