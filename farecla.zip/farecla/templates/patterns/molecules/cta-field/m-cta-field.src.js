// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeCtaField = {
//     attach: (context) => {
//       once('m-cta-field', '.m-cta-field', context).forEach((el) => {
//         behaviors.fareclaMoleculeCtaField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
