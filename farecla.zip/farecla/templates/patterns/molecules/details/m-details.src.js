// (({ behaviors }) => {
//   behaviors.fareclaMoleculeDetails = {
//     attach: (context) => {
//       once('m-details', '.m-details', context).forEach((el) => {
//         behaviors.fareclaMoleculeDetails.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
