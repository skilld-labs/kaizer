// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeFlexField = {
//     attach: (context) => {
//       once('m-flex-field', '.m-flex-field', context).forEach((el) => {
//         behaviors.fareclaMoleculeFlexField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
