// (({ behaviors }) => {
//   behaviors.fareclaMoleculeFormElementLabel = {
//     attach: (context) => {
//       once('m-form-element-label', '.m-form-element-label', context).forEach(
//         (el) => {
//           behaviors.fareclaMoleculeFormElementLabel.handler(el);
//         },
//       );
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
