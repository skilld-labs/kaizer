// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeGridField = {
//     attach: (context) => {
//       once('m-grid-field', '.m-grid-field', context).forEach((el) => {
//         behaviors.fareclaMoleculeGridField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
