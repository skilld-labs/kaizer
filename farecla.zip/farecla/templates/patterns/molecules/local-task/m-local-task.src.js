// (({ behaviors }) => {
//   behaviors.fareclaMoleculeLocalTask = {
//     attach: (context) => {
//       once('m-local-task', '.m-local-task', context).forEach((el) => {
//         behaviors.fareclaMoleculeLocalTask.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
