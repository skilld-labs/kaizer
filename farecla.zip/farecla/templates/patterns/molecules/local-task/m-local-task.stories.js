import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { useEffect } from '@storybook/client-api';
import DrupalAttribute from 'drupal-attribute';
import { Basic as Button } from '@farecla-components/atoms/button/a-button.stories';
import description from './m-local-task.component.yml';

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.link = Button.render({
    content: args.link || 'View',
    link: true,
  });
  // useEffect(() => { place-your-js-code-here }, [args]);
  return template.render(data);
};

export default {
  title: 'Molecules / Local task',
  // parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};
