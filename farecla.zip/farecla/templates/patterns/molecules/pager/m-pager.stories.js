import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { useEffect } from '@storybook/client-api';
import DrupalAttribute from 'drupal-attribute';
import description from './m-pager.component.yml';

const buildObject = (elements = null) => {
  const constructor = {
    href: '#',
    attributes: new DrupalAttribute(),
  };
  if (!elements) {
    return constructor;
  }
  let pages = {};
  elements.forEach((number) => {
    pages[number] = constructor;
  });
  return pages;
};

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.current = args.current;
  data.items = {};
  if (args.items) {
    if (args.items.first) {
      data.items.first = buildObject();
    }
    if (args.items.previous) {
      data.items.previous = buildObject();
    }
    if (args.items.pages) {
      data.items.pages = buildObject(args.items.pages);
    }
    if (args.items.next) {
      data.items.next = buildObject();
    }
    if (args.items.last) {
      data.items.last = buildObject();
    }
  }
  data.ellipses = args.ellipses;
  // useEffect(() => { place-your-js-code-here }, [args]);
  return template.render(data);
};

export default {
  title: 'Molecules / Pager',
  parameters: {
    backgrounds: { default: 'grey' },
    // layout: 'fullscreen',
  },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => {
    args.current = '1';
    args.items = {
      pages: [1, 2, 3, 4, 5],
      next: true,
      last: true,
    };
    args.ellipses = {
      next: true,
    };

    return BasicRender(args);
  },
};

export const MiddleActive = {
  render: (args = {}) => {
    args.current = '5';
    args.items = {
      first: true,
      previous: true,
      pages: [3, 4, 5, 6, 7],
    };
    args.ellipses = {
      previous: true,
      next: true,
    };

    return BasicRender(args);
  },
};

export const LastActive = {
  render: (args = {}) => {
    args.current = '9';
    args.items = {
      first: true,
      previous: true,
      pages: [5, 6, 7, 8, 9],
    };
    args.ellipses = {
      previous: true,
    };

    return BasicRender(args);
  },
};
