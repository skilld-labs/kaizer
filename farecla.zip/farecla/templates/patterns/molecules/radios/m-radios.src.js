// (({ behaviors }) => {
//   behaviors.fareclaMoleculeRadios = {
//     attach: (context) => {
//       once('m-radios', '.m-radios', context).forEach((el) => {
//         behaviors.fareclaMoleculeRadios.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
