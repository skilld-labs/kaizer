// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeSliderField = {
//     attach: (context) => {
//       once('m-slider-field', '.m-slider-field', context).forEach((el) => {
//         behaviors.fareclaMoleculeSliderField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
