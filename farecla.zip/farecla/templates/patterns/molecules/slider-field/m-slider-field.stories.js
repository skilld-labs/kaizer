import { defRender, defArgTypes } from '@farecla-storybook-plugin';

// Uncomment next line if you need specific javascript for your component in storybook,
// which shouldn't be a part of drupal's behavior javascript.
// import { useEffect } from '@storybook/client-api';

// Uncomment next line if you need to set DrupalAttribute to the other variable than "attributes" in twig.
// import DrupalAttribute from 'drupal-attribute';

import description from './m-slider-field.ui_patterns.yml';

const defContent = () => {
  const items = [];
  for (let i = 1; i <= 10; i++) {
    items.push(
      `<div style="text-align: center; padding: 30px 16px; background-color: var(--color-grey-light-grey); color: var(--color-grey-black);">Slide ${i}</div>`,
    );
  }
  return items;
};

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  if (args.label) {
    data.label = args.label !== true ? args.label : 'Lorem ipsum';
  }
  data.items = args.items || defContent();
  if (!data.slider_type) {
    data.slider_type = Object.keys(
      Object.values(description)[0].settings.slider_type.options,
    )[0];
  }
  // useEffect(() => {
  //   place-your-js-code-here
  // }, [args]);
  return template.render(data);
};

export default {
  title: 'Molecules / Slider field',
  parameters: { layout: 'fullscreen' },
  argTypes: {
    label: {
      name: 'Label',
      control: {
        type: 'boolean',
      },
    },
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};
