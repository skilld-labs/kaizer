// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeTagField = {
//     attach: (context) => {
//       once('m-tag-field', '.m-tag-field', context).forEach((el) => {
//         behaviors.fareclaMoleculeTagField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
