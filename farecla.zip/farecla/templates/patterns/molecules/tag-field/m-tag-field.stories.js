import { defRender, defArgTypes } from '@farecla-storybook-plugin';

// Uncomment next line if you need specific javascript for your component in storybook,
// which shouldn't be a part of drupal's behavior javascript.
// import { useEffect } from '@storybook/client-api';

// Uncomment next line if you need to set DrupalAttribute to the other variable than "attributes" in twig.
// import DrupalAttribute from 'drupal-attribute';

import description from './m-tag-field.ui_patterns.yml';

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.label = args.label || args.showLabel ? 'Lorem ipsum' : '';
  data.item = args.item || 'Lorem ipsum';
  if (args.link) {
    data.item_href = '#';
  }
  if (!data.tag_color_type) {
    data.tag_color_type = Object.keys(
      Object.values(description)[0].settings.tag_color_type.options,
    )[0];
  }
  // useEffect(() => {
  //   place-your-js-code-here
  // }, [args]);
  return template.render(data);
};

export default {
  title: 'Molecules/Tag field',
  parameters: {
    backgrounds: { default: 'grey' },
    // layout: 'fullscreen',
  },
  argTypes: {
    showLabel: {
      name: 'Show label',
      control: {
        type: 'boolean',
      },
    },
    link: {
      name: 'Link',
      control: {
        type: 'boolean',
      },
    },
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};
