// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeTeaser = {
//     attach: (context) => {
//       once('m-teaser', '.m-teaser', context).forEach((el) => {
//         behaviors.fareclaMoleculeTeaser.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
