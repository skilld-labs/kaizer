import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { Basic as TextField } from '@farecla-components/molecules/text-field/m-text-field.stories';
import { ResponsiveImage } from '@farecla-components/atoms/image/a-image.stories';
// Uncomment next line if you need specific javascript for your component in storybook,
// which shouldn't be a part of drupal's behavior javascript.
// import { useEffect } from '@storybook/client-api';

// Uncomment next line if you need to set DrupalAttribute to the other variable than "attributes" in twig.
// import DrupalAttribute from 'drupal-attribute';

import description from './m-teaser.ui_patterns.yml';

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  data.media = ResponsiveImage.render({
    group: 'teaser',
  });
  data.title = TextField.render({
    item: args.title || 'Lorem ipsum',
    item_type: 'a-text--header-3',
    item_href: '#',
  });
  // useEffect(() => {
  //   place-your-js-code-here
  // }, [args]);
  return template.render(data);
};

export default {
  title: 'Molecules/Teaser',
  // parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Basic = {
  render: (args = {}) => BasicRender(args),
};
