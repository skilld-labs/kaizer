// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaMoleculeTextField = {
//     attach: (context) => {
//       once('m-text-field', '.m-text-field', context).forEach((el) => {
//         behaviors.fareclaMoleculeTextField.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
