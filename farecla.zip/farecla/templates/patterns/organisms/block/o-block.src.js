// /**
//  * @file
//  * This is component script template.
//  */
// (({ behaviors }) => {
//   behaviors.fareclaOrganismBlock = {
//     attach: (context) => {
//       once('o-block', '.o-block', context).forEach((el) => {
//         behaviors.fareclaOrganismBlock.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
