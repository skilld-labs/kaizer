import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { Basic as TextField } from '@farecla-components/molecules/text-field/m-text-field.stories';
import { Basic as CtaField } from '@farecla-components/molecules/cta-field/m-cta-field.stories';
import { Basic as FlexField } from '@farecla-components/molecules/flex-field/m-flex-field.stories';
import { Basic as TagField } from '@farecla-components/molecules/tag-field/m-tag-field.stories';
import { Basic as GridField } from '@farecla-components/molecules/grid-field/m-grid-field.stories';
import { ResponsiveImage } from '@farecla-components/atoms/image/a-image.stories';
// Uncomment next line if you need specific javascript for your component in storybook,
// which shouldn't be a part of drupal's behavior javascript.
// import { useEffect } from '@storybook/client-api';

// Uncomment next line if you need to set DrupalAttribute to the other variable than "attributes" in twig.
// import DrupalAttribute from 'drupal-attribute';

import description from './o-block.ui_patterns.yml';

const BasicRender = (args) => {
  const { data, template } = defRender(args, description);
  if (args.label_above) {
    data.label_above = args.label_above;
  }
  if (args.tags) {
    data.tags = args.tags;
  }
  if (args.cta_next_to_label) {
    data.cta_next_to_label = args.cta_next_to_label;
  }
  if (args.label) {
    data.label = args.label;
  }
  if (args.cta_next_to_label) {
    data.cta_next_to_label = args.cta_next_to_label;
  }
  if (args.cta_top_right) {
    data.cta_top_right = args.cta_top_right;
  }
  if (args.side_media_small) {
    data.side_media_small = args.side_media_small;
  }
  if (args.side_media_normal) {
    data.side_media_normal = args.side_media_normal;
  }
  if (args.side_media_big) {
    data.side_media_big = args.side_media_big;
  }
  if (args.description) {
    data.description = args.description;
  }
  if (args.regular_cta) {
    data.regular_cta = args.regular_cta;
  }
  if (args.content) {
    data.content = args.content;
  }
  if (args.footer_media) {
    data.footer_media = args.footer_media;
  }
  // useEffect(() => {
  //   place-your-js-code-here
  // }, [args]);
  return template.render(data);
};

export default {
  title: 'Organisms/Block',
  parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const BasicFirst = {
  render: (args = {}) => {
    let ctaType = 'a-button--four';
    if (args.background_color && args.background_color !== 'default') {
      if (args.background_color === 'Grey Black') {
        ctaType = 'a-button--three';
      }
      if (args.background_color === 'Yellow Primary') {
        ctaType = 'a-button--two';
      }
    }
    args.tags = FlexField.render({
      gap: 'h-flex--gap-4',
      items: [
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
      ],
    });
    args.label = TextField.render({
      item: 'Label',
      item_tag: 'h1',
      item_type: 'a-text--header-1',
      item_thick_underline: true,
    });
    args.cta_next_to_label = CtaField.render({
      item: 'CTA next to label',
      item_type: ctaType,
      trailing_icon: 'chevron',
    });
    args.cta_top_right = CtaField.render({
      item: 'CTA top right',
      item_type: ctaType,
      trailing_icon: 'chevron',
    });
    args.description = TextField.render({
      item: 'Description lorem ipsum dolor sit amet, consectetur adipiscing elit. In laoreet sapien ligula, quis ultricies nisi tristique eu. Ut luctus, velit a consequat sodales, tellus mi tempus eros, eget lacinia mauris ante non lacus.',
    });
    args.regular_cta = CtaField.render({
      item: 'Regular CTA',
      item_type: ctaType,
      trailing_icon: 'chevron',
    });
    args.content = GridField.render({
      columns: 'h-grid--three-columns',
      gap: 'h-grid--g-1',
    });
    args.footer_media = ResponsiveImage.render({
      group: 'block_footer',
    });
    return BasicRender(args);
  },
};

export const BasicSecond = {
  render: (args = {}) => {
    let ctaType = 'a-button--four';
    if (args.background_color && args.background_color !== 'default') {
      if (args.background_color === 'Grey Black') {
        ctaType = 'a-button--three';
      }
      if (args.background_color === 'Yellow Primary') {
        ctaType = 'a-button--two';
      }
    }
    args.tags = FlexField.render({
      gap: 'h-flex--gap-4',
      items: [
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
      ],
    });
    args.label = TextField.render({
      item: 'Label',
      item_tag: 'h1',
      item_type: 'a-text--header-1',
      item_thick_underline: true,
    });
    args.side_media_small = ResponsiveImage.render({
      group: 'block_media_small',
    });
    args.cta_top_right = CtaField.render({
      item: 'CTA top right',
      item_type: ctaType,
      trailing_icon: 'chevron',
    });
    args.description = TextField.render({
      item: 'Description lorem ipsum dolor sit amet, consectetur adipiscing elit. In laoreet sapien ligula, quis ultricies nisi tristique eu. Ut luctus, velit a consequat sodales, tellus mi tempus eros, eget lacinia mauris ante non lacus.',
    });
    return BasicRender(args);
  },
};

export const BasicThird = {
  render: (args = {}) => {
    let ctaType = 'a-button--four';
    if (args.background_color && args.background_color !== 'default') {
      if (args.background_color === 'Grey Black') {
        ctaType = 'a-button--three';
      }
      if (args.background_color === 'Yellow Primary') {
        ctaType = 'a-button--two';
      }
    }
    args.label = TextField.render({
      item: 'Label',
      item_tag: 'h1',
      item_type: 'a-text--header-1',
      item_thick_underline: true,
    });
    args.side_media_normal = ResponsiveImage.render({
      group: 'block_media_normal',
    });
    args.regular_cta = CtaField.render({
      item: 'Regular CTA',
      item_type: ctaType,
      trailing_icon: 'chevron',
    });
    args.description = TextField.render({
      item: 'Description lorem ipsum dolor sit amet, consectetur adipiscing elit. In laoreet sapien ligula, quis ultricies nisi tristique eu. Ut luctus, velit a consequat sodales, tellus mi tempus eros, eget lacinia mauris ante non lacus.',
    });
    return BasicRender(args);
  },
};

export const BasicFourth = {
  render: (args = {}) => {
    let ctaType = 'a-button--four';
    if (args.background_color && args.background_color !== 'default') {
      if (args.background_color === 'Grey Black') {
        ctaType = 'a-button--three';
      }
      if (args.background_color === 'Yellow Primary') {
        ctaType = 'a-button--two';
      }
    }
    args.tags = FlexField.render({
      gap: 'h-flex--gap-4',
      items: [
        TagField.render({
          tag_color_type:
            args.background_color && args.background_color !== 'default'
              ? 'm-tag-field--c-1'
              : 'm-tag-field--c-3',
          link: true,
        }),
      ],
    });
    args.label = TextField.render({
      item: 'Label',
      item_tag: 'h1',
      item_type: 'a-text--header-1',
      item_thick_underline: true,
    });
    args.side_media_big = ResponsiveImage.render({
      group: 'block_media_big',
    });
    args.regular_cta = CtaField.render({
      item: 'Regular CTA',
      item_type: ctaType,
      trailing_icon: 'chevron',
    });
    args.description = TextField.render({
      item: 'Description lorem ipsum dolor sit amet, consectetur adipiscing elit. In laoreet sapien ligula, quis ultricies nisi tristique eu. Ut luctus, velit a consequat sodales, tellus mi tempus eros, eget lacinia mauris ante non lacus.',
    });
    return BasicRender(args);
  },
};

export const Basic = {
  render: (args = {}) => {
    if (
      !args.label &&
      !args.label_above &&
      !args.content &&
      !args.side_media_small
    ) {
      args.label =
        "Ignore this story. It's exist only for storybook internal calls";
    }
    return BasicRender(args);
  },
};
