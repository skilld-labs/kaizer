// (({ behaviors }) => {
//   behaviors.fareclaOrganismBranding = {
//     attach: (context) => {
//       once('o-branding', '.o-branding', context).forEach((el) => {
//         behaviors.fareclaOrganismBranding.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
