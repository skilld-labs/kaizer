(({ behaviors }) => {
  behaviors.fareclaOrganismBreadcrumb = {
    attach: (context) => {
      once('o-breadcrumb', '.o-breadcrumb', context).forEach((el) => {
        behaviors.fareclaOrganismBreadcrumb.handler(el);
      });
    },
    handler: (el) => {
      const button = el.querySelector('.o-breadcrumb__toggle');
      if (button) {
        button.addEventListener('click', () => {
          el.classList.add('o-breadcrumb--expanded');
        });
      }
    },
  };
})(Drupal);
