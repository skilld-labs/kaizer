// (({ behaviors }) => {
//   behaviors.fareclaTemplatePage = {
//     attach: (context) => {
//       once('t-page', '.t-page', context).forEach((el) => {
//         behaviors.fareclaTemplatePage.handler(el);
//       });
//     },
//     handler: (el) => {
//       // eslint-disable-next-line no-console
//       console.log(el);
//     },
//   };
// })(Drupal);
