import { defRender, defArgTypes } from '@farecla-storybook-plugin';
import { useEffect } from '@storybook/client-api';
import DrupalAttribute from 'drupal-attribute';
import { Basic as Button } from '@farecla-components/atoms/button/a-button.stories';
import { Basic as Text } from '@farecla-components/atoms/text/a-text.stories';
import { Basic as Menu } from '@farecla-components/molecules/menu/m-menu.stories';
import { Basic as StatusMessages } from '@farecla-components/molecules/status-messages/m-status-messages.stories';
import { Basic as Grid } from '@farecla-components/helpers/grid/h-grid.stories';
import { Basic as Branding } from '@farecla-components/organisms/branding/o-branding.stories';
import { Basic as Breadcrumb } from '@farecla-components/organisms/breadcrumb/o-breadcrumb.stories';
import { Basic as LocalTasks } from '@farecla-components/organisms/local-tasks/o-local-tasks.stories';
import { Basic as Block } from '@farecla-components/organisms/block/o-block.stories';
import { Basic as SliderField } from '@farecla-components/molecules/slider-field/m-slider-field.stories';
import { Basic as TextField } from '@farecla-components/molecules/text-field/m-text-field.stories';
import { Basic as CtaField } from '@farecla-components/molecules/cta-field/m-cta-field.stories';
import { Basic as GridField } from '@farecla-components/molecules/grid-field/m-grid-field.stories';
import { Basic as Teaser } from '@farecla-components/molecules/teaser/m-teaser.stories';
import { ResponsiveImage } from '@farecla-components/atoms/image/a-image.stories';
import * as Banner from '@farecla-components/molecules/banner/m-banner.stories';
import description from './t-page.component.yml';

const BasicRender = (args) => {
  const storyDefaultRender = defRender(args, description);
  const { data, template } = storyDefaultRender;
  data.page = {};
  data.page.branding = Branding.render();
  data.page.main_navigation = Menu.render();
  data.page.user_actions = Button.render({
    content: args.authorised ? 'Logout' : 'Login',
    href: '#',
  });
  if (args.system) {
    data.page.system = args.system;
  }
  data.page.breadcrumb = Breadcrumb.render();
  data.page.main_content = args.main_content || Grid.render();
  data.page.copyright = Text.render({
    content: '@ Copyright',
  });
  data.page.secondary_navigation = Menu.render();
  // useEffect(() => { place-your-js-code-here }, [args]);
  return template.render(data);
};

export default {
  title: 'Templates/Page',
  parameters: { layout: 'fullscreen' },
  argTypes: {
    ...defArgTypes(description),
  },
};

export const Anonymous = {
  render: (args) => BasicRender(args),
};

export const Authorised = {
  render: (args) => {
    args.authorised = true;
    return BasicRender(args);
  },
};

export const Administrator = {
  render: (args) => {
    args.system = [
      LocalTasks.render(),
      StatusMessages.render({
        type: args.system_messages_type,
      }),
    ].join('');
    args.authorised = true;
    return BasicRender(args);
  },
};

Administrator.argTypes = {
  system_messages_type: {
    name: 'Type of system message',
    options: ['Status', 'Warning', 'Error', 'Information'],
    control: {
      type: 'radio',
    },
  },
};

export const Homepage = {
  render: (args) => {
    args.authorised = true;
    args.main_content = [
      SliderField.render({
        container: true,
        width: 'h-container--w-1',
        vertical_margin: 'h-container--vm-1',
        horizontal_padding: 'h-container--hp-1',
        type: 'h-slider--banner',
        items: [
          Banner.Basic.render({
            title: 'G360 - Save time and money',
            body: 'Live comparative data gathered from an A-class bodyshop group over a 6-month period revealed that G360 did more than twice the number of jobs per bottle compared to another leading brand.',
            cta: 'Discover',
          }),
          Banner.NoBody.render(),
          Banner.NoCTA.render(),
          Banner.onlyCTA.render(),
        ],
      }),
      Block.render({
        width: 'h-container--w-1',
        vertical_margin: 'h-container--vm-3',
        horizontal_padding: 'h-container--hp-2',
        label: TextField.render({
          item: 'Discover our products per market',
          item_tag: 'h2',
          item_type: 'a-text--header-2',
          item_thick_underline: true,
        }),
        content: GridField.render({
          columns: 'h-grid--five-columns',
          gap: 'h-grid--g-1',
          items: [
            Teaser.render({
              title: 'Automotive',
            }),
            Teaser.render({
              title: 'Marine',
            }),
            Teaser.render({
              title: 'Transport',
            }),
            Teaser.render({
              title: 'Wood',
            }),
            Teaser.render({
              title: 'Composite',
            }),
          ],
        }),
      }),
      Block.render({
        width: 'h-container--w-1',
        horizontal_padding: 'h-container--hp-2',
        vertical_padding: 'h-container--vp-2',
        background_color: 'h-container--bc-1',
        label: TextField.render({
          item: 'Maximize your productivity with Farécla',
          item_tag: 'h2',
          item_type: 'a-text--header-2',
          item_thick_underline: true,
        }),
        description: TextField.render({
          item: 'An in-depth look at how to effectively use Farécla products to improve your workflow and increase your productivity, through real-world case studies and product demonstrations to help you get the job done.',
        }),
        regular_cta: CtaField.render({
          item: 'Discover',
          item_type: 'a-button--three',
          item_trailing_icon: 'chevron',
        }),
        side_media_normal: ResponsiveImage.render({
          group: 'block_media_normal',
        }),
      }),
      Block.render({
        width: 'h-container--w-1',
        horizontal_padding: 'h-container--hp-2',
        vertical_padding: 'h-container--vp-3',
        background_color: 'h-container--bc-2',
        side_media_small: TextField.render({
          item: 'Can’t find what you need? ',
          item_tag: 'h2',
          item_type: 'a-text--header-2',
          item_thick_underline: true,
        }),
        description: TextField.render({
          item: 'Whether you are looking for something specific or you are unsure what you need to create a clean, defect-free, glossy, protected surface, our customer service and technical team are always happy to help.',
          item_type: 'a-text--header-4',
        }),
        regular_cta: CtaField.render({
          item: 'Contact us',
          item_type: 'a-button--two',
          item_trailing_icon: 'chevron',
        }),
      }),
    ].join('');
    return BasicRender(args);
  },
};
